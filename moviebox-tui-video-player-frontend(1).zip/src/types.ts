export type MediaType = "movie" | "series" | "anime" | "live";
export type StreamFormat = "hls" | "dash" | "mp4" | "webm";

export interface Stream {
  url: string;
  format: StreamFormat;
  label: string;
  quality: string;
}

export interface Title {
  id: string;
  title: string;
  type: MediaType;
  year: number;
  rating: number;
  duration: string;
  maturity: string;
  genres: string[];
  description: string;
  poster: string;
  backdrop: string;
  accent: string;
  streams: Stream[];
  featured?: boolean;
  trending?: boolean;
  comingSoon?: boolean;
  live?: boolean;
  channel?: string;
}

export interface ThemeDef {
  id: string;
  name: string;
  swatch: string;
}

export interface Settings {
  theme: string;
  defaultFormat: StreamFormat | "auto";
  autoplayNext: boolean;
}

export interface HistoryEntry {
  id: string;
  progress: number;
  duration: number;
  updatedAt: number;
}

export interface DownloadItem {
  id: string;
  title: string;
  poster: string;
  quality: string;
  progress: number;
  status: "downloading" | "completed";
  updatedAt: number;
}
