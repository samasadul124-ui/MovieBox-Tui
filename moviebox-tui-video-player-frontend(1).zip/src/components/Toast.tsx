interface ToastProps {
  toast: { msg: string; id: number } | null;
}

export default function Toast({ toast }: ToastProps) {
  if (!toast) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-[60] flex justify-center px-4 pb-24 md:pb-8">
      <div
        key={toast.id}
        className="animate-fade-up flex items-center gap-2.5 rounded-full border border-white/10 bg-zinc-900/90 px-4 py-2.5 text-sm font-medium text-white shadow-2xl shadow-black/50 backdrop-blur-xl"
      >
        <span className="h-2 w-2 shrink-0 rounded-full bg-[var(--accent)]" />
        {toast.msg}
      </div>
    </div>
  );
}
