import type { Settings } from "../types";
import { THEMES } from "../data/themes";
import { useEscape, useLockBody } from "../hooks/useModal";
import { CheckIcon, CloseIcon } from "./icons";

interface SettingsModalProps {
  settings: Settings;
  onChange: (s: Settings) => void;
  onClose: () => void;
}

const FORMATS: { id: Settings["defaultFormat"]; label: string }[] = [
  { id: "auto", label: "Auto" },
  { id: "hls", label: "HLS" },
  { id: "dash", label: "DASH" },
  { id: "mp4", label: "MP4" },
  { id: "webm", label: "WebM" },
];

const SHORTCUTS: [string, string][] = [
  ["Space / K", "Play or pause"],
  ["← / →", "Seek ±10s"],
  ["↑ / ↓", "Volume"],
  ["M", "Mute"],
  ["F", "Fullscreen"],
  ["/", "Search"],
  ["Esc", "Close"],
];

export default function SettingsModal({
  settings,
  onChange,
  onClose,
}: SettingsModalProps) {
  useEscape(onClose);
  useLockBody();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="animate-scale-in glass max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-3xl border border-white/10"
      >
        <div className="sticky top-0 flex items-center justify-between border-b border-white/10 bg-[#0d0d14]/80 px-6 py-4 backdrop-blur">
          <h2 className="font-display text-xl font-bold text-white">Settings</h2>
          <button
            type="button"
            aria-label="Close"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white/20"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-7 px-6 py-6">
          {/* theme */}
          <section>
            <h3 className="mb-3 text-sm font-semibold text-white">Theme</h3>
            <div className="flex flex-wrap gap-3">
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => onChange({ ...settings, theme: t.id })}
                  className={`flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition ${
                    settings.theme === t.id
                      ? "border-[var(--accent)] bg-[var(--accent)]/15 text-white"
                      : "border-white/15 text-white/70 hover:border-white/30"
                  }`}
                >
                  <span
                    className="h-4 w-4 rounded-full"
                    style={{ background: t.swatch }}
                  />
                  {t.name}
                  {settings.theme === t.id && (
                    <CheckIcon className="h-4 w-4 text-[var(--accent)]" />
                  )}
                </button>
              ))}
            </div>
          </section>

          {/* default format */}
          <section>
            <h3 className="mb-3 text-sm font-semibold text-white">
              Preferred stream format
            </h3>
            <p className="mb-3 text-xs text-white/50">
              When a title offers multiple formats, prefer this one.
            </p>
            <div className="flex flex-wrap gap-2">
              {FORMATS.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => onChange({ ...settings, defaultFormat: f.id })}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                    settings.defaultFormat === f.id
                      ? "bg-white text-black"
                      : "bg-white/10 text-white/80 hover:bg-white/20"
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </section>

          {/* autoplay next */}
          <section>
            <h3 className="mb-3 text-sm font-semibold text-white">Playback</h3>
            <button
              type="button"
              onClick={() =>
                onChange({ ...settings, autoplayNext: !settings.autoplayNext })
              }
              className="flex w-full items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3"
            >
              <span className="text-sm text-white">Auto-play next episode</span>
              <span
                className={`relative h-6 w-11 rounded-full transition ${
                  settings.autoplayNext ? "bg-[var(--accent)]" : "bg-white/15"
                }`}
              >
                <span
                  className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${
                    settings.autoplayNext ? "left-[22px]" : "left-0.5"
                  }`}
                />
              </span>
            </button>
          </section>

          {/* shortcuts */}
          <section>
            <h3 className="mb-3 text-sm font-semibold text-white">
              Keyboard shortcuts
            </h3>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {SHORTCUTS.map(([key, desc]) => (
                <div
                  key={key}
                  className="flex items-center justify-between rounded-xl bg-white/5 px-3 py-2"
                >
                  <span className="text-xs text-white/50">{desc}</span>
                  <kbd className="rounded bg-white/10 px-2 py-1 font-mono text-[11px] text-white">
                    {key}
                  </kbd>
                </div>
              ))}
            </div>
          </section>

          <p className="pb-2 text-center font-mono text-[11px] text-white/35">
            MovieBox Web · a front-end for MovieBox-TUI · no media is hosted
          </p>
        </div>
      </div>
    </div>
  );
}
