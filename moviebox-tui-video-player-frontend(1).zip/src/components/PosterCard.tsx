import { useState } from "react";
import type { Title } from "../types";
import { BookmarkFillIcon, BookmarkIcon, PlayIcon, InfoIcon } from "./icons";

interface PosterCardProps {
  title: Title;
  bookmarked: boolean;
  progress?: number;
  onOpen: (t: Title) => void;
  onPlay: (t: Title) => void;
  onToggleBookmark: (t: Title) => void;
}

export default function PosterCard({
  title,
  bookmarked,
  progress = 0,
  onOpen,
  onPlay,
  onToggleBookmark,
}: PosterCardProps) {
  const [imgFailed, setImgFailed] = useState(false);

  return (
    <div
      onClick={() => onOpen(title)}
      className="group relative aspect-[2/3] w-32 shrink-0 cursor-pointer overflow-hidden rounded-xl bg-zinc-900 ring-1 ring-white/5 transition-all duration-300 hover:z-20 hover:scale-[1.04] hover:ring-white/20 sm:w-40 md:w-48"
    >
      {/* poster / fallback gradient */}
      {imgFailed ? (
        <div
          className={`absolute inset-0 bg-gradient-to-br ${title.accent} flex items-end p-3`}
        >
          <span className="font-display text-lg font-bold leading-tight text-white drop-shadow">
            {title.title}
          </span>
        </div>
      ) : (
        <img
          src={title.poster}
          alt={title.title}
          loading="lazy"
          onError={() => setImgFailed(true)}
          className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
      )}

      {/* top gradient for legibility */}
      <div className="absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-black/60 to-transparent" />

      {/* live badge */}
      {title.live && (
        <span className="absolute left-2 top-2 flex items-center gap-1 rounded bg-red-600 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white shadow">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
          Live
        </span>
      )}
      {title.comingSoon && (
        <span className="absolute left-2 top-2 rounded bg-white/15 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-white backdrop-blur">
          Coming soon
        </span>
      )}
      {!title.live && title.channel && (
        <span className="absolute left-2 top-2 rounded bg-black/60 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-white/80">
          {title.channel}
        </span>
      )}

      {/* bookmark */}
      <button
        type="button"
        aria-label={bookmarked ? "Remove from library" : "Add to library"}
        onClick={(e) => {
          e.stopPropagation();
          onToggleBookmark(title);
        }}
        className={`absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-black/50 backdrop-blur transition ${
          bookmarked
            ? "text-[var(--accent)]"
            : "text-white opacity-0 hover:text-white group-hover:opacity-100"
        }`}
      >
        {bookmarked ? (
          <BookmarkFillIcon className="h-4 w-4" />
        ) : (
          <BookmarkIcon className="h-4 w-4" />
        )}
      </button>

      {/* hover overlay */}
      <div className="absolute inset-0 flex flex-col justify-between bg-gradient-to-t from-black/90 via-black/10 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        <div className="flex items-center justify-center pt-[42%]">
          <button
            type="button"
            aria-label={`Play ${title.title}`}
            onClick={(e) => {
              e.stopPropagation();
              onPlay(title);
            }}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-white text-black shadow-xl transition hover:scale-110"
          >
            <PlayIcon className="ml-0.5 h-5 w-5" />
          </button>
        </div>

        <div className="p-3">
          <h3 className="font-display text-sm font-semibold leading-tight text-white">
            {title.title}
          </h3>
          <div className="mt-1 flex items-center gap-2 text-[11px] font-medium text-white/70">
            {title.live ? (
              <span className="flex items-center gap-1.5 font-mono font-semibold text-red-400">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-400" />
                {title.channel} · {title.duration}
              </span>
            ) : (
              <>
                {title.rating > 0 && (
                  <span className="text-[var(--accent)]">★ {title.rating.toFixed(1)}</span>
                )}
                <span>{title.year}</span>
                <span>{title.duration}</span>
              </>
            )}
          </div>
          <div className="mt-1.5 flex flex-wrap gap-1">
            {title.genres.slice(0, 2).map((g) => (
              <span
                key={g}
                className="rounded bg-white/10 px-1.5 py-0.5 text-[10px] text-white/80"
              >
                {g}
              </span>
            ))}
          </div>
          <button
            type="button"
            aria-label="More info"
            onClick={(e) => {
              e.stopPropagation();
              onOpen(title);
            }}
            className="mt-2.5 flex items-center gap-1.5 rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-semibold text-white transition hover:bg-white/25"
          >
            <InfoIcon className="h-3.5 w-3.5" />
            Details
          </button>
        </div>
      </div>

      {/* continue watching progress */}
      {progress > 0 && progress < 0.98 && (
        <div className="absolute inset-x-0 bottom-0 h-1 bg-white/20">
          <div
            className="h-full bg-gradient-to-r from-[var(--accent)] to-[var(--accent-2)]"
            style={{ width: `${Math.round(progress * 100)}%` }}
          />
        </div>
      )}
    </div>
  );
}
