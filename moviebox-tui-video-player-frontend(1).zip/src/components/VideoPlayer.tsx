import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import Hls from "hls.js";
import { MediaPlayer } from "dashjs";
import type { Title } from "../types";
import { detectFormat, FORMAT_META, formatTime } from "../lib/streams";
import {
  ChevronDownIcon,
  CloseIcon,
  GaugeIcon,
  MaximizeIcon,
  MinimizeIcon,
  PauseIcon,
  PictureInPictureIcon,
  PlayIcon,
  SkipBackIcon,
  SkipForwardIcon,
  SpinnerIcon,
  SunIcon,
  VolumeHighIcon,
  VolumeLowIcon,
  VolumeMuteIcon,
} from "./icons";

type DashPlayer = ReturnType<ReturnType<typeof MediaPlayer>["create"]>;

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];

const clamp = (n: number, min: number, max: number) =>
  Math.max(min, Math.min(max, n));

interface VideoPlayerProps {
  title: Title;
  initialStreamIndex?: number;
  startTime?: number;
  onClose?: () => void;
  onProgress?: (time: number, duration: number) => void;
  onEnded?: () => void;
}

function IconButton({
  onClick,
  label,
  children,
  className = "",
}: {
  onClick?: () => void;
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className={`flex h-11 w-11 items-center justify-center rounded-full text-white/90 transition hover:bg-white/10 hover:text-white sm:h-10 sm:w-10 ${className}`}
    >
      {children}
    </button>
  );
}

function Menu({
  open,
  onClose,
  align = "right",
  children,
}: {
  open: boolean;
  onClose: () => void;
  align?: "left" | "right";
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <>
      <div className="fixed inset-0 z-40" onClick={onClose} />
      <div
        className={`absolute bottom-full z-50 mb-2 min-w-[190px] overflow-hidden rounded-xl border border-white/10 bg-zinc-900/95 py-1.5 shadow-2xl shadow-black/60 backdrop-blur-xl ${
          align === "right" ? "right-0" : "left-0"
        }`}
      >
        {children}
      </div>
    </>
  );
}

function MenuItem({
  active,
  onClick,
  children,
}: {
  active?: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-center justify-between gap-3 px-3.5 py-2 text-left text-sm transition hover:bg-white/10 ${
        active ? "text-white" : "text-zinc-300"
      }`}
    >
      {children}
    </button>
  );
}

export default function VideoPlayer({
  title,
  initialStreamIndex = 0,
  startTime = 0,
  onClose,
  onProgress,
  onEnded,
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const dashRef = useRef<DashPlayer | null>(null);
  const hideTimerRef = useRef<number | null>(null);
  const progressRef = useRef({ time: 0, duration: 0 });
  const startTimeRef = useRef(startTime);
  const onProgressRef = useRef(onProgress);
  const onEndedRef = useRef(onEnded);
  const draggingRef = useRef(false);

  /* touch gesture refs */
  const lastTapRef = useRef(0);
  const tapTimerRef = useRef<number | null>(null);
  const seekFlashTimerRef = useRef<number | null>(null);
  const gestureRef = useRef({
    active: false,
    mode: null as null | "volume" | "brightness" | "horizontal",
    startX: 0,
    startY: 0,
    startVolume: 1,
  });

  const streams = title.streams;
  const [streamIndex, setStreamIndex] = useState(
    Math.min(initialStreamIndex, streams.length - 1)
  );

  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [rate, setRate] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [hlsLevels, setHlsLevels] = useState<
    { height: number; bitrate: number; index: number }[]
  >([]);
  const [hlsLevel, setHlsLevel] = useState(-1);
  const [menu, setMenu] = useState<"format" | "speed" | "quality" | null>(null);
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [brightness, setBrightness] = useState(1);
  const [seekFlash, setSeekFlash] = useState<{
    dir: "back" | "fwd";
    key: number;
  } | null>(null);
  const [gesture, setGesture] = useState<{
    type: "volume" | "brightness";
    value: number;
  } | null>(null);
  const [pip, setPip] = useState(false);
  const [pipSupported] = useState(
    () =>
      typeof document !== "undefined" &&
      "pictureInPictureEnabled" in document &&
      document.pictureInPictureEnabled
  );

  onProgressRef.current = onProgress;
  onEndedRef.current = onEnded;

  const stream = streams[streamIndex];
  const format = stream ? detectFormat(stream.url) : "mp4";
  const meta = FORMAT_META[format];

  /* ---------------------------------------------------------------- */
  /* Engine + native listeners setup                                   */
  /* ---------------------------------------------------------------- */
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !stream) return;

    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }
    if (dashRef.current) {
      try {
        dashRef.current.reset();
      } catch {
        /* noop */
      }
      dashRef.current = null;
    }

    setLoading(true);
    setError(null);
    setHlsLevels([]);
    setHlsLevel(-1);
    setCurrentTime(0);
    setDuration(0);
    setBuffered(0);

    const onTimeUpdate = () => {
      setCurrentTime(video.currentTime);
      progressRef.current.time = video.currentTime;
      progressRef.current.duration = video.duration || 0;
    };
    const onDuration = () => setDuration(video.duration || 0);
    const onProgress = () => {
      try {
        if (video.buffered.length) {
          setBuffered(video.buffered.end(video.buffered.length - 1));
        }
      } catch {
        /* noop */
      }
    };
    const onPlay = () => setPlaying(true);
    const onPause = () => {
      setPlaying(false);
      onProgressRef.current?.(
        progressRef.current.time,
        progressRef.current.duration
      );
    };
    const onWaiting = () => setLoading(true);
    const onPlaying = () => {
      setLoading(false);
      setError(null);
    };
    const onCanPlay = () => setLoading(false);
    const onEnded = () => {
      setPlaying(false);
      onProgressRef.current?.(
        progressRef.current.duration,
        progressRef.current.duration
      );
      onEndedRef.current?.();
    };
    const onError = () => {
      setLoading(false);
      setError("Unable to load this stream.");
    };
    const onVolume = () => {
      setVolume(video.volume);
      setMuted(video.muted);
    };
    const onLoadedMetadata = () => {
      setDuration(video.duration || 0);
      if (startTimeRef.current > 0) {
        try {
          video.currentTime = startTimeRef.current;
        } catch {
          /* noop */
        }
        startTimeRef.current = 0;
      }
      tryPlay();
    };

    const tryPlay = () => {
      const p = video.play();
      if (p && typeof p.catch === "function") {
        p.catch(() => {
          /* autoplay may be blocked — user can press play */
        });
      }
    };

    video.addEventListener("timeupdate", onTimeUpdate);
    video.addEventListener("durationchange", onDuration);
    video.addEventListener("progress", onProgress);
    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("waiting", onWaiting);
    video.addEventListener("playing", onPlaying);
    video.addEventListener("canplay", onCanPlay);
    video.addEventListener("ended", onEnded);
    video.addEventListener("error", onError);
    video.addEventListener("volumechange", onVolume);
    video.addEventListener("loadedmetadata", onLoadedMetadata);

    /* ---- engine selection ---- */
    if (format === "hls") {
      if (Hls.isSupported()) {
        const hls = new Hls({ enableWorker: true, backBufferLength: 60 });
        hls.loadSource(stream.url);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          setHlsLevels(
            hls.levels.map((l, i) => ({
              height: l.height,
              bitrate: l.bitrate,
              index: i,
            }))
          );
          setLoading(false);
        });
        hls.on(Hls.Events.LEVEL_SWITCHED, (_e, data) => setHlsLevel(data.level));
        hls.on(Hls.Events.ERROR, (_e, data) => {
          if (data.fatal) {
            setLoading(false);
            setError("Stream error — try switching to another format.");
          }
        });
        hlsRef.current = hls;
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = stream.url;
      } else {
        setLoading(false);
        setError("HLS is not supported in this browser.");
      }
    } else if (format === "dash") {
      try {
        const player = MediaPlayer().create();
        player.initialize(video, stream.url, true);
        player.on("streamInitialized", () => setLoading(false));
        player.on("playbackError", () => {
          setLoading(false);
          setError("DASH playback error.");
        });
        dashRef.current = player;
      } catch {
        setLoading(false);
        setError("DASH playback failed to start.");
      }
    } else {
      video.src = stream.url;
      video.load();
    }

    return () => {
      onProgressRef.current?.(
        progressRef.current.time,
        progressRef.current.duration
      );
      video.removeEventListener("timeupdate", onTimeUpdate);
      video.removeEventListener("durationchange", onDuration);
      video.removeEventListener("progress", onProgress);
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("waiting", onWaiting);
      video.removeEventListener("playing", onPlaying);
      video.removeEventListener("canplay", onCanPlay);
      video.removeEventListener("ended", onEnded);
      video.removeEventListener("error", onError);
      video.removeEventListener("volumechange", onVolume);
      video.removeEventListener("loadedmetadata", onLoadedMetadata);
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      if (dashRef.current) {
        try {
          dashRef.current.reset();
        } catch {
          /* noop */
        }
        dashRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [streamIndex, title.id]);

  /* ---------------------------------------------------------------- */
  /* Controls auto-hide                                                */
  /* ---------------------------------------------------------------- */
  const poke = useCallback(() => {
    setControlsVisible(true);
    if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    hideTimerRef.current = window.setTimeout(() => {
      if (!videoRef.current?.paused && !menu) setControlsVisible(false);
    }, 2800);
  }, [menu]);

  useEffect(() => {
    poke();
    return () => {
      if (hideTimerRef.current) window.clearTimeout(hideTimerRef.current);
    };
  }, [poke]);

  useEffect(
    () => () => {
      if (tapTimerRef.current) window.clearTimeout(tapTimerRef.current);
      if (seekFlashTimerRef.current) window.clearTimeout(seekFlashTimerRef.current);
    },
    []
  );

  /* ---------------------------------------------------------------- */
  /* Actions                                                            */
  /* ---------------------------------------------------------------- */
  const togglePlay = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      const p = video.play();
      if (p && typeof p.catch === "function") p.catch(() => {});
    } else {
      video.pause();
    }
    poke();
  }, [poke]);

  const seekBy = useCallback(
    (delta: number) => {
      const video = videoRef.current;
      if (!video) return;
      const next = Math.max(
        0,
        Math.min(video.currentTime + delta, video.duration || 0)
      );
      video.currentTime = next;
      setCurrentTime(next);
      poke();
    },
    [poke]
  );

  const seekTo = useCallback((fraction: number) => {
    const video = videoRef.current;
    if (!video || !video.duration) return;
    video.currentTime = fraction * video.duration;
    setCurrentTime(fraction * video.duration);
  }, []);

  const toggleMute = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    poke();
  }, [poke]);

  const changeVolume = useCallback(
    (v: number) => {
      const video = videoRef.current;
      if (!video) return;
      video.volume = v;
      video.muted = v === 0;
      setVolume(v);
      poke();
    },
    [poke]
  );

  const changeRate = useCallback((r: number) => {
    const video = videoRef.current;
    if (!video) return;
    video.playbackRate = r;
    setRate(r);
    setMenu(null);
  }, []);

  const selectStream = useCallback((i: number) => {
    setStreamIndex(i);
    setMenu(null);
  }, []);

  const selectHlsLevel = useCallback((i: number) => {
    if (hlsRef.current) hlsRef.current.currentLevel = i;
    setHlsLevel(i);
    setMenu(null);
  }, []);

  const toggleFullscreen = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    } else {
      el.requestFullscreen().catch(() => {});
    }
  }, []);

  const togglePiP = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    try {
      if (document.pictureInPictureElement) {
        document.exitPictureInPicture().catch(() => {});
      } else {
        video.requestPictureInPicture().catch(() => {});
      }
    } catch {
      /* noop */
    }
  }, []);

  useEffect(() => {
    const onFs = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onEnter = () => setPip(true);
    const onLeave = () => setPip(false);
    video.addEventListener("enterpictureinpicture", onEnter);
    video.addEventListener("leavepictureinpicture", onLeave);
    return () => {
      video.removeEventListener("enterpictureinpicture", onEnter);
      video.removeEventListener("leavepictureinpicture", onLeave);
    };
  }, []);

  /* ---------------------------------------------------------------- */
  /* Touch gestures                                                     */
  /* ---------------------------------------------------------------- */
  const showSeekFeedback = useCallback((dir: "back" | "fwd") => {
    setSeekFlash({ dir, key: Date.now() });
    if (seekFlashTimerRef.current) window.clearTimeout(seekFlashTimerRef.current);
    seekFlashTimerRef.current = window.setTimeout(
      () => setSeekFlash(null),
      750
    );
  }, []);

  const handlePointerDown = (e: React.PointerEvent) => {
    if (e.pointerType !== "touch") return;
    const g = gestureRef.current;
    g.active = true;
    g.mode = null;
    g.startX = e.clientX;
    g.startY = e.clientY;
    g.startVolume = videoRef.current?.volume ?? volume;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const g = gestureRef.current;
    if (!g.active || e.pointerType !== "touch") return;
    const rect = videoRef.current?.getBoundingClientRect();
    if (!rect) return;
    const dx = e.clientX - g.startX;
    const dy = e.clientY - g.startY;

    if (g.mode === null) {
      if (Math.abs(dy) > 12 && Math.abs(dy) > Math.abs(dx)) {
        g.mode =
          e.clientX < rect.left + rect.width / 2 ? "brightness" : "volume";
      } else if (Math.abs(dx) > 12) {
        g.mode = "horizontal";
      }
    }

    if (g.mode === "volume") {
      const video = videoRef.current;
      if (video) {
        const newVol = clamp(g.startVolume - dy / rect.height, 0, 1);
        video.volume = newVol;
        video.muted = newVol === 0;
        setVolume(newVol);
        setGesture({ type: "volume", value: newVol });
      }
    } else if (g.mode === "brightness") {
      const delta = -dy / rect.height;
      setBrightness((b) => {
        const next = clamp(b + delta, 0.15, 1);
        setGesture({ type: "brightness", value: next });
        return next;
      });
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    const g = gestureRef.current;
    const hadGesture = g.mode !== null;
    g.active = false;
    g.mode = null;

    if (hadGesture) {
      setGesture(null);
      return;
    }

    if (e.pointerType === "mouse") {
      togglePlay();
      return;
    }

    /* touch tap / double-tap */
    const now = Date.now();
    if (now - lastTapRef.current < 300) {
      if (tapTimerRef.current) window.clearTimeout(tapTimerRef.current);
      lastTapRef.current = 0;
      const rect = videoRef.current?.getBoundingClientRect();
      if (!rect) return;
      const dir: "back" | "fwd" =
        e.clientX < rect.left + rect.width / 2 ? "back" : "fwd";
      seekBy(dir === "back" ? -10 : 10);
      showSeekFeedback(dir);
    } else {
      lastTapRef.current = now;
      tapTimerRef.current = window.setTimeout(() => {
        setControlsVisible((v) => !v);
      }, 300);
    }
  };

  const handlePointerCancel = () => {
    gestureRef.current.active = false;
    gestureRef.current.mode = null;
    setGesture(null);
  };

  /* keyboard shortcuts */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose?.();
        return;
      }
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") return;
      switch (e.key.toLowerCase()) {
        case " ":
        case "k":
          e.preventDefault();
          togglePlay();
          break;
        case "m":
          toggleMute();
          break;
        case "f":
          toggleFullscreen();
          break;
        case "arrowright":
          seekBy(10);
          break;
        case "arrowleft":
          seekBy(-10);
          break;
        case "arrowup":
          e.preventDefault();
          changeVolume(Math.min(1, volume + 0.1));
          break;
        case "arrowdown":
          e.preventDefault();
          changeVolume(Math.max(0, volume - 0.1));
          break;
        default:
          break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [
    togglePlay,
    toggleMute,
    toggleFullscreen,
    seekBy,
    changeVolume,
    volume,
    onClose,
  ]);

  const progress = duration > 0 ? currentTime / duration : 0;
  const bufferedFrac = duration > 0 ? Math.min(1, buffered / duration) : 0;

  const handleSeekPointer = (clientX: number) => {
    const el = containerRef.current?.querySelector(
      "[data-seekbar]"
    ) as HTMLElement | null;
    if (!el || !duration) return;
    const rect = el.getBoundingClientRect();
    const frac = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    seekTo(frac);
  };

  return (
    <div
      ref={containerRef}
      className="group relative h-full w-full select-none overflow-hidden bg-black"
      onMouseMove={poke}
      onMouseLeave={() => {
        if (videoRef.current && !videoRef.current.paused) setControlsVisible(false);
      }}
    >
      <video
        ref={videoRef}
        className="absolute inset-0 h-full w-full object-contain"
        style={{ touchAction: "none" }}
        playsInline
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerCancel}
      />

      {/* brightness overlay */}
      <div
        className="pointer-events-none absolute inset-0 z-10 bg-black transition-opacity duration-150"
        style={{ opacity: 1 - brightness }}
      />

      {/* top gradient */}
      <div
        className={`pointer-events-none absolute inset-x-0 top-0 z-20 h-32 bg-gradient-to-b from-black/80 to-transparent transition-opacity duration-300 ${
          controlsVisible ? "opacity-100" : "opacity-0"
        }`}
      />

      {/* top bar */}
      <div
        className={`absolute inset-x-0 top-0 z-30 flex items-start justify-between gap-4 p-3 transition-opacity duration-300 sm:p-4 ${
          controlsVisible ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      >
        <div className="flex min-w-0 items-center gap-3">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-[var(--accent)] to-[var(--accent-2)]">
            <span className="font-mono text-sm font-bold text-white">MB</span>
          </div>
          <div className="min-w-0">
            <p className="truncate font-display text-base font-semibold text-white">
              {title.title}
            </p>
            <p className="truncate font-mono text-[11px] uppercase tracking-widest text-white/50">
              {title.type === "live" ? "Live stream" : "Now streaming"}
            </p>
          </div>
        </div>
        <button
          type="button"
          aria-label="Close player"
          onClick={onClose}
          className="flex h-11 w-11 items-center justify-center rounded-full bg-black/40 text-white/90 transition hover:bg-black/70 hover:text-white sm:h-10 sm:w-10"
        >
          <CloseIcon className="h-5 w-5" />
        </button>
      </div>

      {/* center loading */}
      <div
        className={`pointer-events-none absolute inset-0 z-20 flex items-center justify-center transition-opacity duration-300 ${
          loading ? "opacity-100" : "opacity-0"
        }`}
      >
        <div className="flex flex-col items-center gap-3">
          <SpinnerIcon className="h-12 w-12 text-white/90" />
          <span className="font-mono text-xs uppercase tracking-widest text-white/60">
            buffering
          </span>
        </div>
      </div>

      {/* seek feedback (double tap) */}
      {seekFlash && (
        <div
          key={seekFlash.key}
          className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center"
        >
          <div className="animate-scale-in flex flex-col items-center gap-1.5 rounded-2xl bg-black/60 px-6 py-5 backdrop-blur">
            {seekFlash.dir === "back" ? (
              <SkipBackIcon className="h-10 w-10 text-white" />
            ) : (
              <SkipForwardIcon className="h-10 w-10 text-white" />
            )}
            <span className="font-display text-xl font-bold text-white">
              10 seconds
            </span>
          </div>
        </div>
      )}

      {/* swipe gesture hint */}
      {gesture && (
        <div className="pointer-events-none absolute left-1/2 top-16 z-30 -translate-x-1/2">
          <div className="flex items-center gap-3 rounded-2xl bg-black/70 px-4 py-2.5 backdrop-blur">
            {gesture.type === "volume" ? (
              <VolumeHighIcon className="h-5 w-5 text-white" />
            ) : (
              <SunIcon className="h-5 w-5 text-white" />
            )}
            <div className="h-1.5 w-28 overflow-hidden rounded-full bg-white/20">
              <div
                className="h-full rounded-full bg-white"
                style={{ width: `${Math.round(gesture.value * 100)}%` }}
              />
            </div>
            <span className="w-8 font-mono text-xs text-white">
              {Math.round(gesture.value * 100)}%
            </span>
          </div>
        </div>
      )}

      {error && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/80 p-6">
          <div className="max-w-md text-center">
            <p className="text-lg font-semibold text-white">{error}</p>
            <p className="mt-2 text-sm text-white/60">
              Try a different format or quality from the menu below.
            </p>
            {streams.length > 1 && (
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {streams.map((s, i) => (
                  <button
                    key={s.url}
                    type="button"
                    onClick={() => selectStream(i)}
                    className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
                      i === streamIndex
                        ? "bg-white text-black"
                        : "bg-white/10 text-white hover:bg-white/20"
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* center play / skip */}
      <div
        className={`absolute inset-0 z-20 flex items-center justify-center gap-6 transition-opacity duration-300 ${
          !playing && !loading && !error
            ? "opacity-100"
            : "pointer-events-none opacity-0"
        }`}
        onClick={togglePlay}
      >
        <button
          type="button"
          aria-label="Back 10 seconds"
          onClick={(e) => {
            e.stopPropagation();
            seekBy(-10);
          }}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur transition hover:bg-white/20"
        >
          <SkipBackIcon className="h-6 w-6" />
        </button>
        <button
          type="button"
          aria-label={playing ? "Pause" : "Play"}
          onClick={(e) => {
            e.stopPropagation();
            togglePlay();
          }}
          className="flex h-20 w-20 items-center justify-center rounded-full bg-white text-black shadow-2xl transition hover:scale-105"
        >
          {playing ? (
            <PauseIcon className="h-8 w-8" />
          ) : (
            <PlayIcon className="ml-1 h-8 w-8" />
          )}
        </button>
        <button
          type="button"
          aria-label="Forward 10 seconds"
          onClick={(e) => {
            e.stopPropagation();
            seekBy(10);
          }}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur transition hover:bg-white/20"
        >
          <SkipForwardIcon className="h-6 w-6" />
        </button>
      </div>

      {/* bottom controls */}
      <div
        className={`absolute inset-x-0 bottom-0 z-30 bg-gradient-to-t from-black/90 via-black/50 to-transparent pb-[env(safe-area-inset-bottom)] pt-14 transition-opacity duration-300 ${
          controlsVisible ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      >
        {/* seek bar */}
        <div className="group/bar relative mx-4 mb-1 h-5">
          <div
            data-seekbar
            className="absolute inset-x-0 top-1/2 h-1 -translate-y-1/2 cursor-pointer rounded-full bg-white/20"
            onClick={(e) => handleSeekPointer(e.clientX)}
            onPointerDown={(e) => {
              draggingRef.current = true;
              (e.target as HTMLElement).setPointerCapture(e.pointerId);
              handleSeekPointer(e.clientX);
            }}
            onPointerMove={(e) => {
              const rect = (
                e.currentTarget as HTMLElement
              ).getBoundingClientRect();
              const frac = Math.max(
                0,
                Math.min(1, (e.clientX - rect.left) / rect.width)
              );
              setHoverTime(frac * duration);
              if (draggingRef.current) handleSeekPointer(e.clientX);
            }}
            onPointerUp={(e) => {
              draggingRef.current = false;
              (e.target as HTMLElement).releasePointerCapture(e.pointerId);
            }}
            onMouseEnter={() => setHoverTime(null)}
            onMouseLeave={() => setHoverTime(null)}
          >
            <div
              className="absolute inset-y-0 left-0 rounded-full bg-white/25"
              style={{ width: `${bufferedFrac * 100}%` }}
            />
            <div
              className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-[var(--accent)] to-[var(--accent-2)]"
              style={{ width: `${progress * 100}%` }}
            />
            <div
              className="absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white opacity-0 shadow transition-opacity group-hover/bar:opacity-100"
              style={{ left: `${progress * 100}%` }}
            />
          </div>
          {hoverTime !== null && (
            <div className="pointer-events-none absolute -top-8 -translate-x-1/2 rounded bg-black/80 px-2 py-1 font-mono text-[11px] text-white">
              {formatTime(hoverTime)}
            </div>
          )}
        </div>

        {/* control row */}
        <div className="flex items-center gap-0.5 px-2 pb-2 sm:gap-1 sm:px-3 sm:pb-3">
          <IconButton label={playing ? "Pause" : "Play"} onClick={togglePlay}>
            {playing ? (
              <PauseIcon className="h-5 w-5" />
            ) : (
              <PlayIcon className="h-5 w-5" />
            )}
          </IconButton>
          <div className="hidden sm:block">
            <IconButton label="Back 10 seconds" onClick={() => seekBy(-10)}>
              <SkipBackIcon className="h-5 w-5" />
            </IconButton>
          </div>
          <div className="hidden sm:block">
            <IconButton label="Forward 10 seconds" onClick={() => seekBy(10)}>
              <SkipForwardIcon className="h-5 w-5" />
            </IconButton>
          </div>

          <div className="group/vol flex items-center gap-1.5">
            <IconButton label={muted ? "Unmute" : "Mute"} onClick={toggleMute}>
              {muted || volume === 0 ? (
                <VolumeMuteIcon className="h-5 w-5" />
              ) : volume < 0.5 ? (
                <VolumeLowIcon className="h-5 w-5" />
              ) : (
                <VolumeHighIcon className="h-5 w-5" />
              )}
            </IconButton>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={muted ? 0 : volume}
              onChange={(e) => changeVolume(Number(e.target.value))}
              className="slider hidden w-20 opacity-0 transition-all duration-200 group-hover/vol:opacity-100 sm:block"
            />
          </div>

          <span className="ml-1 font-mono text-xs tabular-nums text-white/70 sm:ml-2">
            {formatTime(currentTime)} <span className="text-white/40">/</span>{" "}
            {duration > 0 ? formatTime(duration) : "--:--"}
          </span>

          <div className="flex-1" />

          {/* format button */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setMenu(menu === "format" ? null : "format")}
              className="flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-2 text-xs font-semibold text-white transition hover:bg-white/20"
            >
              <span
                className="inline-block h-2 w-2 rounded-full"
                style={{ background: meta.color }}
              />
              <span className="hidden sm:inline">{stream.label}</span>
              <ChevronDownIcon className="h-3.5 w-3.5" />
            </button>
            <Menu open={menu === "format"} onClose={() => setMenu(null)}>
              <p className="px-3.5 pb-1 pt-0.5 font-mono text-[10px] uppercase tracking-widest text-white/40">
                Format & source
              </p>
              {streams.map((s, i) => {
                const f = FORMAT_META[s.format];
                return (
                  <MenuItem
                    key={s.url}
                    active={i === streamIndex}
                    onClick={() => selectStream(i)}
                  >
                    <span className="flex items-center gap-2">
                      <span
                        className="inline-block h-2 w-2 rounded-full"
                        style={{ background: f.color }}
                      />
                      <span className="font-semibold">{s.label}</span>
                    </span>
                    {i === streamIndex && (
                      <span className="text-[var(--accent)]">✓</span>
                    )}
                  </MenuItem>
                );
              })}
            </Menu>
          </div>

          {/* quality button (HLS) */}
          {hlsLevels.length > 0 && (
            <div className="relative hidden sm:block">
              <button
                type="button"
                onClick={() => setMenu(menu === "quality" ? null : "quality")}
                className="flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-2 text-xs font-semibold text-white transition hover:bg-white/20"
              >
                <GaugeIcon className="h-3.5 w-3.5" />
                {hlsLevel === -1
                  ? "Auto"
                  : `${hlsLevels.find((l) => l.index === hlsLevel)?.height ?? ""}p`}
              </button>
              <Menu open={menu === "quality"} onClose={() => setMenu(null)}>
                <MenuItem
                  active={hlsLevel === -1}
                  onClick={() => selectHlsLevel(-1)}
                >
                  <span>Auto</span>
                  {hlsLevel === -1 && (
                    <span className="text-[var(--accent)]">✓</span>
                  )}
                </MenuItem>
                {hlsLevels.map((l) => (
                  <MenuItem
                    key={l.index}
                    active={hlsLevel === l.index}
                    onClick={() => selectHlsLevel(l.index)}
                  >
                    <span>{l.height}p</span>
                    {hlsLevel === l.index && (
                      <span className="text-[var(--accent)]">✓</span>
                    )}
                  </MenuItem>
                ))}
              </Menu>
            </div>
          )}

          {/* speed button */}
          <div className="relative hidden sm:block">
            <button
              type="button"
              onClick={() => setMenu(menu === "speed" ? null : "speed")}
              className="flex items-center rounded-full bg-white/10 px-3 py-2 font-mono text-xs font-semibold text-white transition hover:bg-white/20"
            >
              {rate}x
            </button>
            <Menu open={menu === "speed"} onClose={() => setMenu(null)}>
              <p className="px-3.5 pb-1 pt-0.5 font-mono text-[10px] uppercase tracking-widest text-white/40">
                Playback speed
              </p>
              {SPEEDS.map((s) => (
                <MenuItem
                  key={s}
                  active={rate === s}
                  onClick={() => changeRate(s)}
                >
                  <span>{s}x</span>
                  {rate === s && (
                    <span className="text-[var(--accent)]">✓</span>
                  )}
                </MenuItem>
              ))}
            </Menu>
          </div>

          {pipSupported && (
            <IconButton
              label="Picture in picture"
              onClick={togglePiP}
              className={pip ? "text-white" : ""}
            >
              <PictureInPictureIcon className="h-5 w-5" />
            </IconButton>
          )}

          <IconButton label="Fullscreen" onClick={toggleFullscreen}>
            {fullscreen ? (
              <MinimizeIcon className="h-5 w-5" />
            ) : (
              <MaximizeIcon className="h-5 w-5" />
            )}
          </IconButton>
        </div>
      </div>
    </div>
  );
}
