import { useRef } from "react";
import type { Title } from "../types";
import PosterCard from "./PosterCard";
import { ChevronLeftIcon, ChevronRightIcon } from "./icons";

interface ContentRowProps {
  title: string;
  subtitle?: string;
  items: Title[];
  bookmarkedIds: Set<string>;
  progress: Record<string, number>;
  onOpen: (t: Title) => void;
  onPlay: (t: Title) => void;
  onToggleBookmark: (t: Title) => void;
}

export default function ContentRow({
  title,
  subtitle,
  items,
  bookmarkedIds,
  progress,
  onOpen,
  onPlay,
  onToggleBookmark,
}: ContentRowProps) {
  const scrollerRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: 1 | -1) => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * el.clientWidth * 0.85, behavior: "smooth" });
  };

  return (
    <section className="relative">
      <div className="mb-3 flex items-end justify-between px-4 sm:px-6 lg:px-10">
        <div>
          <h2 className="font-display text-lg font-bold text-white sm:text-xl">
            {title}
          </h2>
          {subtitle && (
            <p className="mt-0.5 text-sm text-white/50">{subtitle}</p>
          )}
        </div>
        <div className="hidden gap-1 sm:flex">
          <button
            type="button"
            aria-label={`Scroll ${title} left`}
            onClick={() => scroll(-1)}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white/20"
          >
            <ChevronLeftIcon className="h-4 w-4" />
          </button>
          <button
            type="button"
            aria-label={`Scroll ${title} right`}
            onClick={() => scroll(1)}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white/20"
          >
            <ChevronRightIcon className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div
        ref={scrollerRef}
        className="no-scrollbar flex gap-3 overflow-x-auto scroll-smooth px-4 pb-2 sm:px-6 lg:px-10"
      >
        {items.map((t) => (
          <PosterCard
            key={t.id}
            title={t}
            bookmarked={bookmarkedIds.has(t.id)}
            progress={progress[t.id] ?? 0}
            onOpen={onOpen}
            onPlay={onPlay}
            onToggleBookmark={onToggleBookmark}
          />
        ))}
      </div>
    </section>
  );
}
