import type { Title } from "../types";
import PosterCard from "./PosterCard";
import { BookmarkIcon, CloseIcon } from "./icons";
import { useEscape, useLockBody } from "../hooks/useModal";

interface LibraryModalProps {
  bookmarks: Title[];
  continueWatching: { title: Title; progress: number }[];
  bookmarkedIds: Set<string>;
  progress: Record<string, number>;
  onClose: () => void;
  onOpen: (t: Title) => void;
  onPlay: (t: Title) => void;
  onToggleBookmark: (t: Title) => void;
}

export default function LibraryModal({
  bookmarks,
  continueWatching,
  bookmarkedIds,
  progress,
  onClose,
  onOpen,
  onPlay,
  onToggleBookmark,
}: LibraryModalProps) {
  useEscape(onClose);
  useLockBody();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="animate-scale-in glass flex max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden rounded-3xl border border-white/10"
      >
        <div className="flex items-center justify-between border-b border-white/10 bg-[#0d0d14]/80 px-6 py-4">
          <h2 className="font-display text-xl font-bold text-white">My Library</h2>
          <button
            type="button"
            aria-label="Close"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white/20"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          {/* continue watching */}
          <section>
            <h3 className="mb-3 text-sm font-semibold text-white">
              Continue watching
            </h3>
            {continueWatching.length === 0 ? (
              <EmptyState text="Nothing in progress yet. Start playing something!" />
            ) : (
              <div className="flex flex-wrap gap-3">
                {continueWatching.map(({ title, progress: p }) => (
                  <PosterCard
                    key={title.id}
                    title={title}
                    bookmarked={bookmarkedIds.has(title.id)}
                    progress={p}
                    onOpen={onOpen}
                    onPlay={onPlay}
                    onToggleBookmark={onToggleBookmark}
                  />
                ))}
              </div>
            )}
          </section>

          {/* bookmarks */}
          <section className="mt-8">
            <h3 className="mb-3 text-sm font-semibold text-white">Bookmarks</h3>
            {bookmarks.length === 0 ? (
              <EmptyState text="Your saved titles will appear here." />
            ) : (
              <div className="flex flex-wrap gap-3">
                {bookmarks.map((t) => (
                  <PosterCard
                    key={t.id}
                    title={t}
                    bookmarked
                    progress={progress[t.id] ?? 0}
                    onOpen={onOpen}
                    onPlay={onPlay}
                    onToggleBookmark={onToggleBookmark}
                  />
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-white/15 bg-white/[0.03] px-6 py-10 text-center">
      <BookmarkIcon className="h-7 w-7 text-white/30" />
      <p className="mt-2 text-sm text-white/50">{text}</p>
    </div>
  );
}
