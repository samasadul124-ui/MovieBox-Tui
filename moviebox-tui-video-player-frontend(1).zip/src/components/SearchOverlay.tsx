import { useEffect, useMemo, useRef, useState } from "react";
import type { Title } from "../types";
import PosterCard from "./PosterCard";
import { CloseIcon, SearchIcon } from "./icons";
import { useEscape, useLockBody } from "../hooks/useModal";

interface SearchOverlayProps {
  items: Title[];
  initialQuery?: string;
  bookmarkedIds: Set<string>;
  progress: Record<string, number>;
  onClose: () => void;
  onOpen: (t: Title) => void;
  onPlay: (t: Title) => void;
  onToggleBookmark: (t: Title) => void;
}

export default function SearchOverlay({
  items,
  initialQuery = "",
  bookmarkedIds,
  progress,
  onClose,
  onOpen,
  onPlay,
  onToggleBookmark,
}: SearchOverlayProps) {
  const [query, setQuery] = useState(initialQuery);
  const inputRef = useRef<HTMLInputElement>(null);

  useEscape(onClose);
  useLockBody();

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    return items.filter(
      (t) =>
        t.title.toLowerCase().includes(q) ||
        t.genres.some((g) => g.toLowerCase().includes(q)) ||
        t.type.includes(q)
    );
  }, [query, items]);

  const suggestions = useMemo(
    () => items.filter((t) => t.trending).slice(0, 10),
    [items]
  );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#07070c]/95 backdrop-blur-xl">
      <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-10">
        {/* search bar */}
        <div className="flex items-center gap-3">
          <div className="flex flex-1 items-center gap-3 rounded-full border border-white/15 bg-white/5 px-4 py-3 focus-within:border-[var(--accent)]">
            <SearchIcon className="h-5 w-5 shrink-0 text-white/50" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search movies, series, anime, live TV…"
              className="w-full bg-transparent text-base text-white placeholder:text-white/40 focus:outline-none"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="text-white/50 hover:text-white"
              >
                <CloseIcon className="h-4 w-4" />
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white/20"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
        </div>

        {/* hint */}
        <p className="mt-3 px-2 font-mono text-[11px] uppercase tracking-widest text-white/40">
          Press <kbd className="rounded bg-white/10 px-1.5 py-0.5">/</kbd> anywhere
          to search
        </p>

        {/* results */}
        <div className="mt-6">
          {query.trim() ? (
            <>
              <h2 className="mb-3 font-display text-lg font-bold text-white">
                Results{" "}
                <span className="text-white/40">({results.length})</span>
              </h2>
              {results.length === 0 ? (
                <div className="rounded-2xl border border-white/10 bg-white/5 p-10 text-center">
                  <p className="text-lg font-semibold text-white">
                    No matches for “{query}”
                  </p>
                  <p className="mt-1 text-sm text-white/50">
                    Try a different title, genre, or type.
                  </p>
                </div>
              ) : (
                <div className="flex flex-wrap gap-3">
                  {results.map((t) => (
                    <PosterCard
                      key={t.id}
                      title={t}
                      bookmarked={bookmarkedIds.has(t.id)}
                      progress={progress[t.id] ?? 0}
                      onOpen={onOpen}
                      onPlay={onPlay}
                      onToggleBookmark={onToggleBookmark}
                    />
                  ))}
                </div>
              )}
            </>
          ) : (
            <>
              <h2 className="mb-3 font-display text-lg font-bold text-white">
                Trending now
              </h2>
              <div className="flex flex-wrap gap-3">
                {suggestions.map((t) => (
                  <PosterCard
                    key={t.id}
                    title={t}
                    bookmarked={bookmarkedIds.has(t.id)}
                    progress={progress[t.id] ?? 0}
                    onOpen={onOpen}
                    onPlay={onPlay}
                    onToggleBookmark={onToggleBookmark}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
