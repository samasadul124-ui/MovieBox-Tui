import type { StreamFormat } from "../types";

export function detectFormat(url: string): StreamFormat {
  if (/\.m3u8(\?|#|$)/i.test(url)) return "hls";
  if (/\.mpd(\?|#|$)/i.test(url)) return "dash";
  if (/\.webm(\?|#|$)/i.test(url)) return "webm";
  return "mp4";
}

export const FORMAT_META: Record<
  StreamFormat,
  { label: string; desc: string; color: string }
> = {
  hls: {
    label: "HLS",
    desc: "HTTP Live Streaming — adaptive bitrate .m3u8",
    color: "#22c55e",
  },
  dash: {
    label: "DASH",
    desc: "MPEG-DASH — adaptive bitrate .mpd",
    color: "#f59e0b",
  },
  mp4: {
    label: "MP4",
    desc: "Progressive download — H.264 / AAC",
    color: "#3b82f6",
  },
  webm: {
    label: "WebM",
    desc: "Progressive download — VP8 / VP9 / AV1",
    color: "#8b5cf6",
  },
};

export function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) seconds = 0;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const pad = (n: number) => n.toString().padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}
