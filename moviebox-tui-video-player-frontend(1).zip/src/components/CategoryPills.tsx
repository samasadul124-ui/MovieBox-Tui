const SECTIONS = [
  { id: "movies", label: "Movies" },
  { id: "series", label: "Series" },
  { id: "anime", label: "Anime" },
  { id: "live", label: "Live TV" },
  { id: "docs", label: "Documentaries" },
];

const GENRES = [
  "Sci-Fi",
  "Action",
  "Thriller",
  "Drama",
  "Crime",
  "Horror",
  "Anime",
  "Documentary",
];

interface CategoryPillsProps {
  onBrowseGenre: (genre: string) => void;
}

export default function CategoryPills({ onBrowseGenre }: CategoryPillsProps) {
  const go = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

  return (
    <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 py-3 sm:px-6 lg:px-10">
      <button
        type="button"
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className="shrink-0 rounded-full bg-white px-4 py-1.5 text-sm font-semibold text-black transition hover:bg-white/85"
      >
        All
      </button>
      {SECTIONS.map((s) => (
        <button
          key={s.id}
          type="button"
          onClick={() => go(s.id)}
          className="shrink-0 rounded-full bg-white/10 px-4 py-1.5 text-sm font-medium text-white/80 transition hover:bg-white/20 hover:text-white"
        >
          {s.label}
        </button>
      ))}
      {GENRES.map((g) => (
        <button
          key={g}
          type="button"
          onClick={() => onBrowseGenre(g)}
          className="shrink-0 rounded-full border border-white/10 px-4 py-1.5 text-sm font-medium text-white/60 transition hover:border-white/25 hover:text-white"
        >
          {g}
        </button>
      ))}
    </div>
  );
}
