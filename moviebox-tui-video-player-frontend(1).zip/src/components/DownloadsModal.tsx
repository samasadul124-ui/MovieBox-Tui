import type { DownloadItem } from "../types";
import { useEscape, useLockBody } from "../hooks/useModal";
import {
  CheckIcon,
  CloseIcon,
  DownloadIcon,
  PlayIcon,
  TrashIcon,
} from "./icons";

interface DownloadsModalProps {
  downloads: DownloadItem[];
  onClose: () => void;
  onRemove: (id: string) => void;
  onPlay: (id: string) => void;
}

export default function DownloadsModal({
  downloads,
  onClose,
  onRemove,
  onPlay,
}: DownloadsModalProps) {
  useEscape(onClose);
  useLockBody();

  const downloading = downloads.filter((d) => d.status === "downloading");
  const completed = downloads.filter((d) => d.status === "completed");

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="animate-scale-in glass flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl border border-white/10"
      >
        <div className="flex items-center justify-between border-b border-white/10 bg-[#0d0d14]/80 px-6 py-4">
          <div>
            <h2 className="font-display text-xl font-bold text-white">Downloads</h2>
            <p className="text-xs text-white/50">
              Save titles for offline playback
            </p>
          </div>
          <button
            type="button"
            aria-label="Close"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white transition hover:bg-white/20"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          {downloads.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-white/15 bg-white/[0.03] px-6 py-14 text-center">
              <DownloadIcon className="h-8 w-8 text-white/30" />
              <p className="mt-3 font-semibold text-white">
                Nothing downloaded yet
              </p>
              <p className="mt-1 max-w-xs text-sm text-white/50">
                Find a movie or series and tap “Download” to save it for offline
                watching.
              </p>
            </div>
          ) : (
            <div className="space-y-8">
              {downloading.length > 0 && (
                <section>
                  <h3 className="mb-3 text-sm font-semibold text-white">
                    Downloading{" "}
                    <span className="text-white/40">({downloading.length})</span>
                  </h3>
                  <div className="space-y-2">
                    {downloading.map((d) => (
                      <DownloadRow
                        key={d.id}
                        item={d}
                        onRemove={onRemove}
                        onPlay={onPlay}
                      />
                    ))}
                  </div>
                </section>
              )}

              {completed.length > 0 && (
                <section>
                  <h3 className="mb-3 text-sm font-semibold text-white">
                    Ready to watch{" "}
                    <span className="text-white/40">({completed.length})</span>
                  </h3>
                  <div className="space-y-2">
                    {completed.map((d) => (
                      <DownloadRow
                        key={d.id}
                        item={d}
                        onRemove={onRemove}
                        onPlay={onPlay}
                      />
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function DownloadRow({
  item,
  onRemove,
  onPlay,
}: {
  item: DownloadItem;
  onRemove: (id: string) => void;
  onPlay: (id: string) => void;
}) {
  const done = item.status === "completed";
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-3">
      <img
        src={item.poster}
        alt=""
        className="h-16 w-11 shrink-0 rounded-lg object-cover ring-1 ring-white/10"
      />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold text-white">{item.title}</p>
        <p className="text-xs text-white/50">{item.quality}</p>
        {!done ? (
          <div className="mt-2 flex items-center gap-2">
            <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/15">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[var(--accent)] to-[var(--accent-2)] transition-all"
                style={{ width: `${Math.round(item.progress)}%` }}
              />
            </div>
            <span className="font-mono text-[11px] text-white/60">
              {Math.round(item.progress)}%
            </span>
          </div>
        ) : (
          <p className="mt-1 flex items-center gap-1 text-xs font-medium text-emerald-400">
            <CheckIcon className="h-3.5 w-3.5" />
            Ready to watch
          </p>
        )}
      </div>
      {done && (
        <button
          type="button"
          aria-label={`Play ${item.title}`}
          onClick={() => onPlay(item.id)}
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white text-black transition hover:scale-105"
        >
          <PlayIcon className="ml-0.5 h-4 w-4" />
        </button>
      )}
      <button
        type="button"
        aria-label="Remove download"
        onClick={() => onRemove(item.id)}
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-white/50 transition hover:bg-white/10 hover:text-white"
      >
        <TrashIcon className="h-4 w-4" />
      </button>
    </div>
  );
}
