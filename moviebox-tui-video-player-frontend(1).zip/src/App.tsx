import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type {
  DownloadItem,
  HistoryEntry,
  Settings,
  Title,
} from "./types";
import { ALL_TITLES, CHANNELS, TITLES, getTitle } from "./data/catalog";
import { useLocalStorage } from "./hooks/useLocalStorage";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import ContentRow from "./components/ContentRow";
import TopTenRow from "./components/TopTenRow";
import CategoryPills from "./components/CategoryPills";
import BottomNav, { type TabId } from "./components/BottomNav";
import DetailsModal from "./components/DetailsModal";
import PlayerOverlay from "./components/PlayerOverlay";
import SearchOverlay from "./components/SearchOverlay";
import SettingsModal from "./components/SettingsModal";
import LibraryModal from "./components/LibraryModal";
import DownloadsModal from "./components/DownloadsModal";
import Toast from "./components/Toast";
import { ClapperboardIcon, TerminalIcon } from "./components/icons";

const DEFAULT_SETTINGS: Settings = {
  theme: "violet",
  defaultFormat: "auto",
  autoplayNext: true,
};

function resolveStreamIndex(
  title: Title,
  explicit: number | undefined,
  preferred: Settings["defaultFormat"]
): number {
  if (explicit !== undefined) return explicit;
  if (preferred !== "auto") {
    const i = title.streams.findIndex((s) => s.format === preferred);
    if (i >= 0) return i;
  }
  return 0;
}

function getResumeTime(id: string, history: Record<string, HistoryEntry>): number {
  const h = history[id];
  if (!h || h.duration <= 0) return 0;
  const frac = h.progress / h.duration;
  return frac > 0.02 && frac < 0.97 ? h.progress : 0;
}

function getRelated(title: Title): Title[] {
  const same = TITLES.filter(
    (t) =>
      t.id !== title.id &&
      t.type === title.type &&
      t.genres.some((g) => title.genres.includes(g))
  );
  const pool =
    same.length >= 4
      ? same
      : TITLES.filter((t) => t.id !== title.id && t.type === title.type);
  return pool.slice(0, 8);
}

type ActiveModal =
  | { kind: "details"; title: Title }
  | { kind: "search"; query?: string }
  | { kind: "library" }
  | { kind: "downloads" }
  | { kind: "settings" };

interface Playing {
  title: Title;
  streamIndex: number;
  startTime: number;
}

export default function App() {
  const [settings, setSettings] = useLocalStorage<Settings>(
    "mb.settings",
    DEFAULT_SETTINGS
  );
  const [library, setLibrary] = useLocalStorage<string[]>("mb.library", []);
  const [history, setHistory] = useLocalStorage<Record<string, HistoryEntry>>(
    "mb.history",
    {}
  );
  const [downloads, setDownloads] = useLocalStorage<DownloadItem[]>(
    "mb.downloads",
    []
  );

  const [activeModal, setActiveModal] = useState<ActiveModal | null>(null);
  const [playing, setPlaying] = useState<Playing | null>(null);
  const [activeTab, setActiveTab] = useState<TabId>("home");
  const [toast, setToast] = useState<{ msg: string; id: number } | null>(null);

  const toastTimer = useRef<number | null>(null);
  const prevCompletedRef = useRef<Set<string>>(new Set());

  /* theme */
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", settings.theme);
  }, [settings.theme]);

  /* toast */
  const notify = useCallback((msg: string) => {
    setToast({ msg, id: Date.now() });
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2600);
  }, []);

  /* simulated download progress */
  useEffect(() => {
    const interval = window.setInterval(() => {
      setDownloads((prev) => {
        let changed = false;
        const next = prev.map((d) => {
          if (d.status === "downloading") {
            changed = true;
            const progress = Math.min(100, d.progress + Math.random() * 6 + 3);
            return {
              ...d,
              progress,
              status:
                progress >= 100
                  ? ("completed" as const)
                  : ("downloading" as const),
              updatedAt: Date.now(),
            };
          }
          return d;
        });
        return changed ? next : prev;
      });
    }, 450);
    return () => window.clearInterval(interval);
  }, [setDownloads]);

  /* download completion toast */
  useEffect(() => {
    const completed = new Set(
      downloads.filter((d) => d.status === "completed").map((d) => d.id)
    );
    completed.forEach((id) => {
      if (!prevCompletedRef.current.has(id)) {
        const d = downloads.find((x) => x.id === id);
        if (d) notify(`Download complete: ${d.title}`);
      }
    });
    prevCompletedRef.current = completed;
  }, [downloads, notify]);

  /* derived data */
  const bookmarkedIds = useMemo(() => new Set(library), [library]);

  const progress = useMemo(() => {
    const map: Record<string, number> = {};
    for (const [id, h] of Object.entries(history)) {
      map[id] = h.duration > 0 ? h.progress / h.duration : 0;
    }
    return map;
  }, [history]);

  const continueWatching = useMemo(() => {
    return Object.entries(history)
      .map(([id, h]) => {
        const title = getTitle(id);
        if (!title || title.live) return null;
        const frac = h.duration > 0 ? h.progress / h.duration : 0;
        if (frac <= 0.02 || frac >= 0.97) return null;
        return { title, progress: frac };
      })
      .filter((x): x is { title: Title; progress: number } => x !== null)
      .sort(
        (a, b) =>
          (history[b.title.id].updatedAt ?? 0) -
          (history[a.title.id].updatedAt ?? 0)
      );
  }, [history]);

  const bookmarks = useMemo(
    () => library.map(getTitle).filter((t): t is Title => Boolean(t)),
    [library]
  );

  const featured = useMemo(
    () => TITLES.find((t) => t.featured) ?? TITLES[0],
    []
  );
  const topTen = useMemo(
    () =>
      TITLES.filter((t) => !t.comingSoon)
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 10),
    []
  );
  const comingSoon = useMemo(() => TITLES.filter((t) => t.comingSoon), []);
  const trending = useMemo(
    () => TITLES.filter((t) => t.trending && !t.comingSoon),
    []
  );

  const rows = useMemo(
    () => [
      {
        id: "movies",
        title: "Movies",
        subtitle: "Feature films and blockbusters",
        items: TITLES.filter((t) => t.type === "movie" && !t.comingSoon),
      },
      {
        id: "series",
        title: "Series",
        subtitle: "Binge-worthy shows",
        items: TITLES.filter((t) => t.type === "series" && !t.comingSoon),
      },
      {
        id: "anime",
        title: "Anime",
        subtitle: "Hand-picked animation",
        items: TITLES.filter((t) => t.type === "anime"),
      },
      {
        id: "docs",
        title: "Documentaries",
        subtitle: "Real stories, beautifully told",
        items: TITLES.filter((t) => t.genres.includes("Documentary")),
      },
      {
        id: "live",
        title: "Live TV",
        subtitle: "Channels streaming around the clock",
        items: CHANNELS,
      },
    ],
    []
  );

  /* actions */
  const playTitle = useCallback(
    (title: Title, streamIndex?: number) => {
      const startTime = getResumeTime(title.id, history);
      setPlaying({
        title,
        streamIndex: resolveStreamIndex(
          title,
          streamIndex,
          settings.defaultFormat
        ),
        startTime,
      });
      setActiveModal(null);
    },
    [history, settings.defaultFormat]
  );

  const closePlayer = useCallback(() => setPlaying(null), []);

  const recordProgress = useCallback(
    (id: string, time: number, duration: number) => {
      if (!Number.isFinite(duration) || duration <= 0) return;
      setHistory((prev) => {
        const frac = time / duration;
        const next = { ...prev };
        if (frac < 0.02 || frac > 0.98) {
          delete next[id];
        } else {
          next[id] = { id, progress: time, duration, updatedAt: Date.now() };
        }
        return next;
      });
    },
    [setHistory]
  );

  const toggleBookmark = useCallback(
    (title: Title) => {
      const exists = library.includes(title.id);
      notify(
        exists
          ? "Removed from your list"
          : `Added “${title.title}” to your list`
      );
      setLibrary((prev) =>
        prev.includes(title.id)
          ? prev.filter((x) => x !== title.id)
          : [...prev, title.id]
      );
    },
    [library, setLibrary, notify]
  );

  const startDownload = useCallback(
    (title: Title) => {
      const exists = downloads.some((d) => d.id === title.id);
      if (exists) {
        notify(`${title.title} is already in your downloads`);
        return;
      }
      setDownloads((prev) =>
        prev.some((d) => d.id === title.id)
          ? prev
          : [
              ...prev,
              {
                id: title.id,
                title: title.title,
                poster: title.poster,
                quality: title.streams[0]?.label ?? "HD",
                progress: 4,
                status: "downloading",
                updatedAt: Date.now(),
              },
            ]
      );
      notify(`Downloading “${title.title}”…`);
    },
    [downloads, setDownloads, notify]
  );

  const removeDownload = useCallback(
    (id: string) => setDownloads((prev) => prev.filter((d) => d.id !== id)),
    [setDownloads]
  );

  const handleDownloadsPlay = useCallback(
    (id: string) => {
      const t = getTitle(id);
      if (t) playTitle(t);
    },
    [playTitle]
  );

  const handleEnded = useCallback(() => {
    if (!settings.autoplayNext) return;
    setPlaying((cur) => {
      if (!cur) return cur;
      const list = ALL_TITLES;
      const idx = list.findIndex((t) => t.id === cur.title.id);
      const after = list.slice(idx + 1).find((t) => t.type === cur.title.type);
      const next = after ?? list.find((t) => t.type === cur.title.type);
      if (!next || next.id === cur.title.id) return cur;
      return {
        title: next,
        streamIndex: resolveStreamIndex(next, undefined, settings.defaultFormat),
        startTime: 0,
      };
    });
  }, [settings.autoplayNext, settings.defaultFormat]);

  /* navigation */
  const openSearch = useCallback((query?: string) => {
    setActiveModal({ kind: "search", query });
    setActiveTab("search");
  }, []);

  const openLibrary = useCallback(() => {
    setActiveModal({ kind: "library" });
    setActiveTab("library");
  }, []);

  const openDownloads = useCallback(() => {
    setActiveModal({ kind: "downloads" });
    setActiveTab("downloads");
  }, []);

  const openSettings = useCallback(() => {
    setActiveModal({ kind: "settings" });
    setActiveTab("settings");
  }, []);

  const goHome = useCallback(() => {
    setActiveModal(null);
    setActiveTab("home");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const closeModal = useCallback(() => {
    setActiveModal(null);
    setActiveTab("home");
  }, []);

  const navigate = useCallback(
    (tab: TabId) => {
      if (tab === "home") goHome();
      else if (tab === "search") openSearch();
      else if (tab === "library") openLibrary();
      else if (tab === "downloads") openDownloads();
      else if (tab === "settings") openSettings();
    },
    [goHome, openSearch, openLibrary, openDownloads, openSettings]
  );

  /* global "/" shortcut */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "/") return;
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA") return;
      if (playing || activeModal) return;
      e.preventDefault();
      openSearch();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [playing, activeModal, openSearch]);

  const detailsTitle =
    activeModal?.kind === "details" ? activeModal.title : null;
  const downloadingCount = downloads.filter(
    (d) => d.status === "downloading"
  ).length;

  return (
    <div className="min-h-screen bg-[#07070c] text-white">
      <Navbar
        libraryCount={library.length}
        onHome={goHome}
        onSearch={() => openSearch()}
        onLibrary={openLibrary}
        onSettings={openSettings}
      />

      <main>
        <Hero
          title={featured}
          bookmarked={bookmarkedIds.has(featured.id)}
          onPlay={playTitle}
          onInfo={(t) => setActiveModal({ kind: "details", title: t })}
          onToggleBookmark={toggleBookmark}
        />

        <div className="relative z-10 -mt-8 space-y-9 pb-24 md:pb-20">
          <CategoryPills onBrowseGenre={(g) => openSearch(g)} />

          {continueWatching.length > 0 && (
            <ContentRow
              title="Continue Watching"
              subtitle="Pick up where you left off"
              items={continueWatching.map((x) => x.title)}
              bookmarkedIds={bookmarkedIds}
              progress={progress}
              onOpen={(t) => setActiveModal({ kind: "details", title: t })}
              onPlay={playTitle}
              onToggleBookmark={toggleBookmark}
            />
          )}

          <TopTenRow
            items={topTen}
            bookmarkedIds={bookmarkedIds}
            progress={progress}
            onOpen={(t) => setActiveModal({ kind: "details", title: t })}
            onPlay={playTitle}
            onToggleBookmark={toggleBookmark}
          />

          <ContentRow
            title="Trending Now"
            subtitle="What everyone is watching"
            items={trending}
            bookmarkedIds={bookmarkedIds}
            progress={progress}
            onOpen={(t) => setActiveModal({ kind: "details", title: t })}
            onPlay={playTitle}
            onToggleBookmark={toggleBookmark}
          />

          <ContentRow
            title="Coming Soon"
            subtitle="New titles arriving soon"
            items={comingSoon}
            bookmarkedIds={bookmarkedIds}
            progress={progress}
            onOpen={(t) => setActiveModal({ kind: "details", title: t })}
            onPlay={playTitle}
            onToggleBookmark={toggleBookmark}
          />

          {rows.map((row) => (
            <section key={row.id} id={row.id} className="scroll-mt-20">
              <ContentRow
                title={row.title}
                subtitle={row.subtitle}
                items={row.items}
                bookmarkedIds={bookmarkedIds}
                progress={progress}
                onOpen={(t) => setActiveModal({ kind: "details", title: t })}
                onPlay={playTitle}
                onToggleBookmark={toggleBookmark}
              />
            </section>
          ))}
        </div>
      </main>

      {/* footer */}
      <footer className="border-t border-white/10 bg-black/40 px-4 py-12 sm:px-6 lg:px-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-6 text-center">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-[var(--accent)] to-[var(--accent-2)]">
              <ClapperboardIcon className="h-5 w-5 text-white" />
            </div>
            <span className="font-display text-xl font-bold text-white">
              Movie<span className="text-gradient">Box</span> Web
            </span>
          </div>

          <p className="max-w-xl text-sm leading-relaxed text-white/50">
            A modern streaming front-end inspired by{" "}
            <a
              href="https://github.com/mesamirh/MovieBox-Tui"
              target="_blank"
              rel="noreferrer"
              className="font-semibold text-white/80 underline decoration-[var(--accent)] underline-offset-2 hover:text-white"
            >
              MovieBox-TUI
            </a>{" "}
            — the Rust terminal client for finding and streaming movies, series,
            anime and live TV.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 font-mono text-xs text-white/60">
            <TerminalIcon className="h-4 w-4 text-[var(--accent)]" />
            <span>HLS · DASH · MP4 · WebM</span>
            <span className="text-white/30">|</span>
            <span>adaptive streaming</span>
          </div>

          <p className="font-mono text-[11px] leading-relaxed text-white/35">
            Demo only — no media is hosted. Content streams from public,
            CORS-enabled test sources (Big Buck Bunny, Sintel, Tears of Steel).
          </p>
        </div>
      </footer>

      {/* spacer for bottom nav on mobile */}
      <div className="h-16 md:hidden" aria-hidden />

      {!playing && (
        <BottomNav
          active={activeTab}
          libraryCount={library.length}
          downloadCount={downloadingCount}
          onNavigate={navigate}
        />
      )}

      {/* overlays */}
      {detailsTitle && (
        <DetailsModal
          title={detailsTitle}
          bookmarked={bookmarkedIds.has(detailsTitle.id)}
          related={getRelated(detailsTitle)}
          download={downloads.find((d) => d.id === detailsTitle.id) ?? null}
          onClose={closeModal}
          onPlay={playTitle}
          onToggleBookmark={toggleBookmark}
          onDownload={startDownload}
          onSelectRelated={(t) => setActiveModal({ kind: "details", title: t })}
        />
      )}

      {activeModal?.kind === "search" && (
        <SearchOverlay
          items={ALL_TITLES}
          initialQuery={activeModal.query ?? ""}
          bookmarkedIds={bookmarkedIds}
          progress={progress}
          onClose={closeModal}
          onOpen={(t) => setActiveModal({ kind: "details", title: t })}
          onPlay={playTitle}
          onToggleBookmark={toggleBookmark}
        />
      )}

      {activeModal?.kind === "library" && (
        <LibraryModal
          bookmarks={bookmarks}
          continueWatching={continueWatching}
          bookmarkedIds={bookmarkedIds}
          progress={progress}
          onClose={closeModal}
          onOpen={(t) => setActiveModal({ kind: "details", title: t })}
          onPlay={playTitle}
          onToggleBookmark={toggleBookmark}
        />
      )}

      {activeModal?.kind === "downloads" && (
        <DownloadsModal
          downloads={downloads}
          onClose={closeModal}
          onRemove={removeDownload}
          onPlay={handleDownloadsPlay}
        />
      )}

      {activeModal?.kind === "settings" && (
        <SettingsModal
          settings={settings}
          onChange={setSettings}
          onClose={closeModal}
        />
      )}

      {playing && (
        <PlayerOverlay
          title={playing.title}
          streamIndex={playing.streamIndex}
          startTime={playing.startTime}
          onClose={closePlayer}
          onProgress={recordProgress}
          onEnded={handleEnded}
        />
      )}

      <Toast toast={toast} />
    </div>
  );
}
