import type { Title } from "../types";
import { BookmarkFillIcon, BookmarkIcon, InfoIcon, PlayIcon } from "./icons";

interface HeroProps {
  title: Title;
  bookmarked: boolean;
  onPlay: (t: Title) => void;
  onInfo: (t: Title) => void;
  onToggleBookmark: (t: Title) => void;
}

export default function Hero({
  title,
  bookmarked,
  onPlay,
  onInfo,
  onToggleBookmark,
}: HeroProps) {
  return (
    <section id="home" className="relative h-[80vh] min-h-[460px] w-full sm:min-h-[560px]">
      {/* backdrop */}
      <div className="absolute inset-0">
        <img
          src={title.backdrop}
          alt=""
          className="h-full w-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#07070c] via-[#07070c]/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#07070c] via-transparent to-[#07070c]/40" />
      </div>

      {/* content */}
      <div className="relative z-10 flex h-full max-w-3xl flex-col justify-end px-4 pb-20 sm:px-6 sm:pb-24 lg:px-10">
        <div className="animate-fade-up">
          <div className="mb-3 flex items-center gap-2">
            <span className="rounded-full bg-[var(--accent)]/15 px-2.5 py-1 font-mono text-[11px] font-semibold uppercase tracking-widest text-[var(--accent)]">
              {title.type === "movie"
                ? "Featured film"
                : title.type === "series"
                ? "Featured series"
                : title.type === "anime"
                ? "Featured anime"
                : "Featured"}
            </span>
            <span className="flex items-center gap-1 text-sm font-semibold text-white/80">
              ★ {title.rating.toFixed(1)}
            </span>
          </div>

          <h1 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight text-white drop-shadow-lg sm:text-6xl lg:text-7xl">
            {title.title}
          </h1>

          <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm font-medium text-white/70">
            <span className="text-white">{title.year}</span>
            <span className="rounded border border-white/20 px-1.5 py-0.5 text-xs text-white/80">
              {title.maturity}
            </span>
            <span>{title.duration}</span>
            <span className="hidden text-white/50 sm:inline">
              {title.genres.join(" · ")}
            </span>
          </div>

          <p className="mt-4 max-w-xl text-sm leading-relaxed text-white/75 sm:text-base">
            {title.description}
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onPlay(title)}
              className="flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-bold text-black shadow-xl transition hover:scale-[1.03] hover:bg-white/90"
            >
              <PlayIcon className="h-5 w-5" />
              Play now
            </button>
            <button
              type="button"
              onClick={() => onInfo(title)}
              className="flex items-center gap-2 rounded-full bg-white/15 px-6 py-3 text-sm font-semibold text-white backdrop-blur transition hover:bg-white/25"
            >
              <InfoIcon className="h-5 w-5" />
              More info
            </button>
            <button
              type="button"
              aria-label="Add to library"
              onClick={() => onToggleBookmark(title)}
              className={`flex h-12 w-12 items-center justify-center rounded-full border border-white/20 bg-black/30 backdrop-blur transition hover:bg-black/50 ${
                bookmarked ? "text-[var(--accent)]" : "text-white"
              }`}
            >
              {bookmarked ? (
                <BookmarkFillIcon className="h-5 w-5" />
              ) : (
                <BookmarkIcon className="h-5 w-5" />
              )}
            </button>
          </div>

          {/* available formats */}
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <span className="font-mono text-[11px] uppercase tracking-widest text-white/40">
              Streams in
            </span>
            {title.streams.map((s) => (
              <span
                key={s.format}
                className="rounded-full border border-white/15 bg-white/5 px-2.5 py-1 font-mono text-[11px] font-semibold uppercase text-white/70"
              >
                {s.format}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
