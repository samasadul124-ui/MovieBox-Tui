import { useEffect, useState } from "react";
import {
  ClapperboardIcon,
  LibraryIcon,
  SearchIcon,
  SettingsIcon,
} from "./icons";

const LINKS = [
  { label: "Home", id: "home" },
  { label: "Movies", id: "movies" },
  { label: "Series", id: "series" },
  { label: "Anime", id: "anime" },
  { label: "Live TV", id: "live" },
];

interface NavbarProps {
  libraryCount: number;
  onHome: () => void;
  onSearch: () => void;
  onLibrary: () => void;
  onSettings: () => void;
}

export default function Navbar({
  libraryCount,
  onHome,
  onSearch,
  onLibrary,
  onSettings,
}: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (id: string) => {
    if (id === "home") {
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-300 ${
        scrolled
          ? "border-b border-white/10 bg-black/70 backdrop-blur-xl"
          : "bg-gradient-to-b from-black/80 to-transparent"
      }`}
    >
      <nav className="flex h-16 items-center gap-4 px-4 sm:px-6 lg:px-10">
        {/* logo */}
        <button
          type="button"
          onClick={onHome}
          className="flex items-center gap-2.5"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[var(--accent)] to-[var(--accent-2)] shadow-lg shadow-black/40">
            <ClapperboardIcon className="h-5 w-5 text-white" />
          </div>
          <div className="flex items-center gap-2">
            <span className="font-display text-lg font-bold tracking-tight text-white">
              Movie<span className="text-gradient">Box</span>
            </span>
            <span className="hidden rounded border border-white/15 bg-white/5 px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-widest text-white/60 sm:inline">
              web
            </span>
          </div>
        </button>

        {/* links */}
        <div className="ml-4 hidden items-center gap-1 md:flex">
          {LINKS.map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => go(l.id)}
              className="rounded-full px-3 py-1.5 text-sm font-medium text-white/70 transition hover:bg-white/10 hover:text-white"
            >
              {l.label}
            </button>
          ))}
        </div>

        <div className="flex-1" />

        {/* actions */}
        <button
          type="button"
          aria-label="Search"
          onClick={onSearch}
          className="flex h-9 w-9 items-center justify-center rounded-full text-white/80 transition hover:bg-white/10 hover:text-white"
        >
          <SearchIcon className="h-5 w-5" />
        </button>
        <button
          type="button"
          aria-label="Library"
          onClick={onLibrary}
          className="relative flex h-9 w-9 items-center justify-center rounded-full text-white/80 transition hover:bg-white/10 hover:text-white"
        >
          <LibraryIcon className="h-5 w-5" />
          {libraryCount > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--accent)] px-1 text-[10px] font-bold text-white">
              {libraryCount}
            </span>
          )}
        </button>
        <button
          type="button"
          aria-label="Settings"
          onClick={onSettings}
          className="flex h-9 w-9 items-center justify-center rounded-full text-white/80 transition hover:bg-white/10 hover:text-white"
        >
          <SettingsIcon className="h-5 w-5" />
        </button>
      </nav>
    </header>
  );
}
