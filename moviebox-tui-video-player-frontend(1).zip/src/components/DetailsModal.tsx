import type { DownloadItem, Title } from "../types";
import { FORMAT_META } from "../lib/streams";
import { useEscape, useLockBody } from "../hooks/useModal";
import {
  BookmarkFillIcon,
  BookmarkIcon,
  CheckIcon,
  CloseIcon,
  DownloadIcon,
  PlayIcon,
} from "./icons";

interface DetailsModalProps {
  title: Title;
  bookmarked: boolean;
  related: Title[];
  download: DownloadItem | null;
  onClose: () => void;
  onPlay: (t: Title, streamIndex?: number) => void;
  onToggleBookmark: (t: Title) => void;
  onDownload: (t: Title) => void;
  onSelectRelated: (t: Title) => void;
}

export default function DetailsModal({
  title,
  bookmarked,
  related,
  download,
  onClose,
  onPlay,
  onToggleBookmark,
  onDownload,
  onSelectRelated,
}: DetailsModalProps) {
  useEscape(onClose);
  useLockBody();

  const downloading = download?.status === "downloading";
  const downloaded = download?.status === "completed";

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="animate-scale-in glass relative flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-t-3xl border border-white/10 sm:rounded-3xl"
      >
        {/* header backdrop */}
        <div className="relative h-44 shrink-0 sm:h-56">
          <img
            src={title.backdrop}
            alt=""
            className="h-full w-full object-cover object-center"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d14] via-[#0d0d14]/40 to-transparent" />
          <button
            type="button"
            aria-label="Close"
            onClick={onClose}
            className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-black/50 text-white transition hover:bg-black/80"
          >
            <CloseIcon className="h-5 w-5" />
          </button>
          <div className="absolute bottom-3 left-4 right-4 sm:left-6">
            <div className="flex items-center gap-2">
              {title.live && (
                <span className="flex items-center gap-1 rounded bg-red-600 px-2 py-0.5 text-[11px] font-bold uppercase tracking-wider text-white">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
                  Live
                </span>
              )}
              {title.comingSoon && (
                <span className="rounded bg-white/15 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider text-white backdrop-blur">
                  Coming soon
                </span>
              )}
              <span className="font-mono text-[11px] uppercase tracking-widest text-white/50">
                {title.type}
              </span>
            </div>
            <h2 className="font-display text-2xl font-bold text-white sm:text-3xl">
              {title.title}
            </h2>
          </div>
        </div>

        {/* body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="flex flex-col gap-5 sm:flex-row">
            <img
              src={title.poster}
              alt={title.title}
              className="hidden h-52 w-36 shrink-0 rounded-xl object-cover ring-1 ring-white/10 sm:block"
            />

            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-white/70">
                {title.rating > 0 ? (
                  <span className="flex items-center gap-1 font-semibold text-white">
                    <span className="text-[var(--accent)]">★</span>
                    {title.rating.toFixed(1)}
                  </span>
                ) : (
                  <span className="font-semibold text-white/80">Coming {title.year}</span>
                )}
                {!title.live && <span>{title.year}</span>}
                <span>{title.duration}</span>
                <span className="rounded border border-white/20 px-1.5 py-0.5 text-xs">
                  {title.maturity}
                </span>
              </div>

              <div className="mt-3 flex flex-wrap gap-1.5">
                {title.genres.map((g) => (
                  <span
                    key={g}
                    className="rounded-full bg-white/10 px-2.5 py-1 text-xs font-medium text-white/80"
                  >
                    {g}
                  </span>
                ))}
              </div>

              <p className="mt-4 text-sm leading-relaxed text-white/75">
                {title.description}
              </p>

              <div className="mt-5 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onPlay(title)}
                  className="flex items-center gap-2 rounded-full bg-white px-6 py-2.5 text-sm font-bold text-black transition hover:scale-[1.03]"
                >
                  <PlayIcon className="h-4 w-4" />
                  {title.comingSoon ? "Watch trailer" : "Play now"}
                </button>
                <button
                  type="button"
                  onClick={() => onToggleBookmark(title)}
                  className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition ${
                    bookmarked
                      ? "bg-[var(--accent)]/20 text-[var(--accent)]"
                      : "bg-white/10 text-white hover:bg-white/20"
                  }`}
                >
                  {bookmarked ? (
                    <BookmarkFillIcon className="h-4 w-4" />
                  ) : (
                    <BookmarkIcon className="h-4 w-4" />
                  )}
                  {bookmarked ? "In library" : "My list"}
                </button>
                <button
                  type="button"
                  onClick={() => onDownload(title)}
                  disabled={downloaded}
                  className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition ${
                    downloaded
                      ? "cursor-default bg-emerald-500/15 text-emerald-400"
                      : "bg-white/10 text-white hover:bg-white/20"
                  }`}
                >
                  {downloaded ? (
                    <>
                      <CheckIcon className="h-4 w-4" />
                      Downloaded
                    </>
                  ) : downloading ? (
                    <>
                      <span className="h-3.5 w-3.5 animate-pulse rounded-full bg-[var(--accent)]" />
                      {Math.round(download?.progress ?? 0)}%
                    </>
                  ) : (
                    <>
                      <DownloadIcon className="h-4 w-4" />
                      Download
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* streams */}
          <div className="mt-6">
            <h3 className="mb-2 font-mono text-[11px] font-semibold uppercase tracking-widest text-white/40">
              Available streams & formats
            </h3>
            <div className="grid gap-2 sm:grid-cols-2">
              {title.streams.map((s, i) => {
                const meta = FORMAT_META[s.format];
                return (
                  <button
                    key={s.url}
                    type="button"
                    onClick={() => onPlay(title, i)}
                    className="group flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-3 text-left transition hover:border-white/25 hover:bg-white/10"
                  >
                    <span
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg"
                      style={{ background: `${meta.color}22`, color: meta.color }}
                    >
                      <span className="font-mono text-xs font-bold">
                        {meta.label.slice(0, 4)}
                      </span>
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-semibold text-white">
                        {s.label}
                      </span>
                      <span className="block truncate text-xs text-white/50">
                        {meta.desc}
                      </span>
                    </span>
                    <PlayIcon className="h-4 w-4 text-white/40 transition group-hover:text-white" />
                  </button>
                );
              })}
            </div>
          </div>

          {/* more like this */}
          {related.length > 0 && (
            <div className="mt-7">
              <h3 className="mb-3 font-mono text-[11px] font-semibold uppercase tracking-widest text-white/40">
                More like this
              </h3>
              <div className="no-scrollbar flex gap-3 overflow-x-auto pb-1">
                {related.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => onSelectRelated(r)}
                    className="group w-28 shrink-0 text-left"
                  >
                    <div className="aspect-[2/3] w-28 overflow-hidden rounded-lg ring-1 ring-white/10 transition group-hover:ring-white/30">
                      <img
                        src={r.poster}
                        alt={r.title}
                        loading="lazy"
                        className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                      />
                    </div>
                    <p className="mt-1.5 line-clamp-2 text-xs font-medium leading-tight text-white/80">
                      {r.title}
                    </p>
                    {r.rating > 0 && (
                      <p className="text-[11px] text-[var(--accent)]">
                        ★ {r.rating.toFixed(1)}
                      </p>
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
