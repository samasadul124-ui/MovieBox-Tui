import {
  DownloadIcon,
  HomeIcon,
  LibraryIcon,
  SearchIcon,
  SettingsIcon,
} from "./icons";

export type TabId = "home" | "search" | "library" | "downloads" | "settings";

interface BottomNavProps {
  active: TabId;
  libraryCount: number;
  downloadCount: number;
  onNavigate: (tab: TabId) => void;
}

const ITEMS: { id: TabId; label: string; icon: typeof HomeIcon }[] = [
  { id: "home", label: "Home", icon: HomeIcon },
  { id: "search", label: "Search", icon: SearchIcon },
  { id: "library", label: "My List", icon: LibraryIcon },
  { id: "downloads", label: "Downloads", icon: DownloadIcon },
  { id: "settings", label: "Settings", icon: SettingsIcon },
];

export default function BottomNav({
  active,
  libraryCount,
  downloadCount,
  onNavigate,
}: BottomNavProps) {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-black/85 backdrop-blur-xl md:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <div className="flex h-16 items-stretch">
        {ITEMS.map(({ id, label, icon: Icon }) => {
          const count =
            id === "library"
              ? libraryCount
              : id === "downloads"
              ? downloadCount
              : 0;
          const isActive = active === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onNavigate(id)}
              className={`relative flex flex-1 flex-col items-center justify-center gap-1 text-[10px] font-medium transition ${
                isActive ? "text-white" : "text-white/50"
              }`}
            >
              {isActive && (
                <span className="absolute top-0 h-0.5 w-8 rounded-full bg-[var(--accent)]" />
              )}
              <span className="relative">
                <Icon className="h-6 w-6" />
                {count > 0 && (
                  <span className="absolute -right-2.5 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--accent)] px-1 text-[9px] font-bold text-white">
                    {count}
                  </span>
                )}
              </span>
              <span>{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
