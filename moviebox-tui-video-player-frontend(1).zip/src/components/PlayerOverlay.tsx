import type { Title } from "../types";
import VideoPlayer from "./VideoPlayer";
import { useLockBody } from "../hooks/useModal";

interface PlayerOverlayProps {
  title: Title;
  streamIndex: number;
  startTime: number;
  onClose: () => void;
  onProgress: (id: string, time: number, duration: number) => void;
  onEnded?: () => void;
}

export default function PlayerOverlay({
  title,
  streamIndex,
  startTime,
  onClose,
  onProgress,
  onEnded,
}: PlayerOverlayProps) {
  useLockBody();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black">
      <div className="h-full w-full">
        <VideoPlayer
          title={title}
          initialStreamIndex={streamIndex}
          startTime={startTime}
          onClose={onClose}
          onProgress={(time, duration) => onProgress(title.id, time, duration)}
          onEnded={onEnded}
        />
      </div>
    </div>
  );
}
