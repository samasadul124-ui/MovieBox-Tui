import type { ThemeDef } from "../types";

export const THEMES: ThemeDef[] = [
  { id: "violet", name: "Violet", swatch: "#8b5cf6" },
  { id: "green", name: "Terminal", swatch: "#22c55e" },
  { id: "sunset", name: "Sunset", swatch: "#f59e0b" },
  { id: "cyan", name: "Ocean", swatch: "#22d3ee" },
  { id: "crimson", name: "Crimson", swatch: "#ef4444" },
];
